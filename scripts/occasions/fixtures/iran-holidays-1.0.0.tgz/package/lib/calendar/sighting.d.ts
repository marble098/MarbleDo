import type { Ymd } from './jalali.js';
/**
 * The evening crescent counts as visible at Tehran sunset when the Moon is
 * more than 2 degrees above the horizon and at least 9.5 degrees from the Sun.
 * The threshold was fitted to official months 1423–1448, and the chained error stays within one day.
 */
export declare function crescentVisible(date: Ymd): boolean;
