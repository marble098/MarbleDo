export type HijriDate = {
    year: number;
    month: number;
    day: number;
    monthLength: number;
};
export declare function hijriFromJdn(jdn: number): HijriDate;
