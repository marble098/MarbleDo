/**
 * Official Iranian Hijri month lengths from crescent sighting.
 * Covers 1 Muharram 1423 through Shawwal 1448
 * (about 26 Esfand 1380 through 18 Farvardin 1406).
 * After that range, month length is estimated from the Tehran astronomical criterion.
 */
export declare const OFFICIAL_HIJRI_START_JDN = 2452350;
export declare const OFFICIAL_HIJRI_MONTHS: readonly (readonly [number, readonly number[]])[];
