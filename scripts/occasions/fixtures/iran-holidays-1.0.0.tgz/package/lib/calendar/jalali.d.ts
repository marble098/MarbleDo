export type Ymd = {
    year: number;
    month: number;
    day: number;
};
/** Noon Julian day number, aligned with the official Iranian calendar tables. */
export declare function gregorianToJdn(year: number, month: number, day: number): number;
export declare function jdnToGregorian(jdn: number): Ymd;
/** Convert a Solar Hijri date to Gregorian with the calendar center's arithmetic. */
export declare function jalaliToGregorian(jy: number, jm: number, jd: number): Ymd;
export declare function gregorianToJalali(gy: number, gm: number, gd: number): Ymd;
export declare function jalaliToJdn(year: number, month: number, day: number): number;
export declare function isJalaliLeapYear(year: number): boolean;
export declare function jalaliMonthLength(year: number, month: number): number;
export declare function eachJalaliDay(year: number): Ymd[];
export declare function formatJalali(date: Ymd): string;
