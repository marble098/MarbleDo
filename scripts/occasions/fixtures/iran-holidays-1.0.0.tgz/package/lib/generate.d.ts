export type HolidayDay = {
    date: string;
    shamsiDate: string;
    isHoliday: boolean;
    holidayDescription: string | null;
};
export type HolidayYear = {
    data: HolidayDay[];
    totalCount: number;
};
export type JustHolidayDay = {
    date: string;
    shamsiDate: string;
    holidayDescription: string;
};
export type JustHolidayYear = {
    data: JustHolidayDay[];
    totalCount: number;
};
export declare function justHolidays(calendar: HolidayYear): JustHolidayYear;
export declare function generateYear(year: number): HolidayYear;
