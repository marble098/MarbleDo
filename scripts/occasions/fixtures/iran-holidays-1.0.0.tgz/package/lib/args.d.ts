export type CliOptions = {
    year: number;
    root: string;
    justHolidays: boolean;
};
export declare function normalizeYear(input: string): number;
export declare function parseCliArgs(args: string[]): CliOptions;
