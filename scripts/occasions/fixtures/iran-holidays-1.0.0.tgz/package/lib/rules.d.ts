import type { HijriDate } from './calendar/hijri.js';
/**
 * time.ir groups occasions on three calendars:
 * - Solar Hijri: national holidays on a fixed date every year
 * - Hijri lunar: religious holidays whose Solar Hijri date moves every year
 * - Gregorian: international occasions. None are official Iranian holidays, so they are omitted.
 *
 * Only occasions that time.ir marks as holidays are included, and only on or after
 * the event they commemorate. Nowruz has no start date. Hijri years before 1 use
 * astronomical numbering, where year 0 is 1 BH, so 53 BH is year -52.
 */
type CalendarDate = {
    year: number;
    month: number;
    day: number;
};
export type ShamsiHoliday = {
    month: number;
    day: number;
    title: string;
    /** First Solar Hijri date on which this holiday exists. */
    since?: CalendarDate;
};
export declare const SHAMSI_HOLIDAYS: readonly ShamsiHoliday[];
export type HijriHoliday = {
    month: number;
    day: number;
    title: string;
    /** Imam Reza's martyrdom is the last day of Safar, which is day 29 when that month is short. */
    onLastDayIfShorter?: boolean;
    /** First Hijri date on which this holiday exists. */
    since?: CalendarDate;
};
export declare const HIJRI_HOLIDAYS: readonly HijriHoliday[];
export declare const HIJRI_MONTH_NAMES: readonly ['محرم', 'صفر', 'ربیع‌الاول', 'ربیع‌الثانی', 'جمادی‌الاول', 'جمادی‌الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذی‌القعده', 'ذی‌الحجه'];
export declare function shamsiHolidayTitles(year: number, month: number, day: number): string[];
export declare function hijriHolidayTitles(date: HijriDate): string[];
export declare function holidayDescription(shamsiTitles: string[], hijriTitles: string[], hijri: HijriDate): string | null;
export {};
