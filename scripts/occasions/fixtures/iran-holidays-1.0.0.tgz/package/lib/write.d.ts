import { type HolidayYear, type JustHolidayYear } from './generate.js';
export type WriteHolidaysOptions = {
    year: number;
    /** Directory that receives the JSON file. Defaults to `dist`. */
    root?: string;
    justHolidays?: boolean;
};
export type WriteHolidaysResult = {
    filePath: string;
    fileName: string;
    holidayCount: number;
    totalCount: number;
    output: HolidayYear | JustHolidayYear;
};
export declare function writeHolidays(options: WriteHolidaysOptions): Promise<WriteHolidaysResult>;
